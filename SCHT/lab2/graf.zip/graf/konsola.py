import subprocess

# Przykładowa komenda do wykonania w terminalu Windows
command = 'C:\\Users\\stasz\\OneDrive - Politechnika Warszawska\\Pulpit\\studia\\semestr 3\\scht\\lab2\\graf\\script.bat'

# Uruchamianie komendy
result = subprocess.run(command, capture_output=True, text=True, shell=True)

# Sprawdzenie wyniku
print(result.returncode)
print(result.stdout)
print(result.stderr)