import heapq
import json
import shutil
from collections import defaultdict

class Graph:
    def __init__(self):
        self.edges = defaultdict(list)

    def add_edge(self, start, end, weight, portS, portD):
        self.edges[start].append((end, weight, portS, portD))
        self.edges[end].append((start, weight, portD, portS))  # Jeśli graf jest nieskierowany

    def dijkstra(self, start, end):
        distances = {vertex: float('infinity') for vertex in self.edges}
        previous_vertices = {vertex: None for vertex in self.edges}
        distances[start] = 0
        priority_queue = [(0, start)]

        while priority_queue:
            current_distance, current_vertex = heapq.heappop(priority_queue)

            if current_distance > distances[current_vertex]:
                continue

            for neighbor, weight, _, _ in self.edges[current_vertex]:
                distance = current_distance + weight

                if distance < distances[neighbor]:
                    distances[neighbor] = distance
                    previous_vertices[neighbor] = current_vertex
                    heapq.heappush(priority_queue, (distance, neighbor))

        path = self._build_path(start, end, previous_vertices)
        return distances[end], path

    def _build_path(self, start, end, previous_vertices):
        path = []
        current_vertex = end
        while current_vertex is not None and current_vertex != start:
            path.insert(0, current_vertex)
            current_vertex = previous_vertices[current_vertex]
        if current_vertex == start:
            path.insert(0, start)
        return path

    def file_builder_switch_host_setup(self,filename, shortestpath,hostports):
        with open(filename, "r") as file_to_send:
            content = file_to_send.read()
            with open("szablondowzoru.json", "r") as file_template:
                new_content = file_template.read()
                line = content.split('\n')
                line.insert(2, new_content)
                content = '\n'.join(line)
                content=content.replace("%1", str(shortestpath[0]))
                content = content.replace("%2", str(int(self.get_edge(shortestpath[0],shortestpath[1])[2])))
                content = content.replace("%3", hostports[shortestpath[0]-1])
                content = content.replace("%4", str(shortestpath[len(shortestpath)-1]))
                content = content.replace("%5", str(shortestpath[0]))

                new_content += ","
                line = content.split('\n')
                line.insert(2, new_content)
                content = '\n'.join(line)
                content = content.replace("%1", str(shortestpath[0]))
                content = content.replace("%2", hostports[shortestpath[0]-1])
                content = content.replace("%3", str(int(self.get_edge(shortestpath[0],shortestpath[1])[2])))
                content = content.replace("%4", str(shortestpath[0]))
                content = content.replace("%5", str(shortestpath[len(shortestpath) - 1]))

                line = content.split('\n')
                line.insert(2, new_content)
                content = '\n'.join(line)
                content = content.replace("%1", str(shortestpath[len(shortestpath) - 1]))
                content = content.replace("%2", hostports[shortestpath[len(shortestpath)-1]-1])
                content = content.replace("%3", str(int(self.get_edge(shortestpath[len(shortestpath)-1],shortestpath[len(shortestpath)-2])[2])))
                content = content.replace("%4", str(shortestpath[len(shortestpath)-1]))
                content = content.replace("%5", str(shortestpath[0]))

                line = content.split('\n')
                line.insert(2, new_content)
                content = '\n'.join(line)
                content = content.replace("%1", str(shortestpath[len(shortestpath) - 1]))
                content = content.replace("%2", str(int(self.get_edge(shortestpath[len(shortestpath) - 1], shortestpath[len(shortestpath) - 2])[2])))
                content = content.replace("%3", hostports[shortestpath[len(shortestpath)-1]-1])
                content = content.replace("%4", str(shortestpath[0]))
                content = content.replace("%5", str(shortestpath[len(shortestpath)-1]))
            with open(filename, 'w') as file_to_send:
                file_to_send.write(content)

    def file_builder_switch_switch_setup(self, filename, shortestpath, hostports):
        with open(filename, "r") as file_to_send:
            content = file_to_send.read()
            for index in range(1,len(shortestpath)-1):
                with open("szablondowzoru.json", "r") as file_template:
                    new_content = file_template.read()
                    new_content += ","
                    line = content.split('\n')
                    line.insert(2, new_content)
                    content = '\n'.join(line)
                    content = content.replace("%1", str(int(shortestpath[index])))
                    content = content.replace("%2", str(int(self.get_edge(shortestpath[index], shortestpath[index+1])[2])))
                    content = content.replace("%3", str(int(self.get_edge(shortestpath[index], shortestpath[index-1])[2])))
                    content = content.replace("%4", str(int(shortestpath[len(shortestpath) - 1])))
                    content = content.replace("%5", str(int(shortestpath[0])))

                    line = content.split('\n')
                    line.insert(2, new_content)
                    content = '\n'.join(line)
                    content = content.replace("%1", str(int(shortestpath[index])))
                    content = content.replace("%2", str(int(self.get_edge(shortestpath[index], shortestpath[index-1])[2])))
                    content = content.replace("%3", str(int(self.get_edge(shortestpath[index], shortestpath[index+1])[2])))
                    content = content.replace("%4", str(int(shortestpath[0])))
                    content = content.replace("%5", str(int(shortestpath[len(shortestpath) - 1])))


            print(content)
            with open(filename, 'w') as file_to_send:
                file_to_send.write(content)
    def get_edge(self, start, end):
        for index in range(len(self.edges[start])):
            if (self.edges[start][index][0] == end):
                return (self.edges[start][index])

    def print_graph(self):
        for vertex, connections in self.edges.items():
            for connection in connections:
                end, weight, portS, portD = connection
                print(f"{vertex} ({portS}) -> {end} ({portD}) : {weight}")

    def copy_and_save(self, source_filename, destination_filename):
        shutil.copyfile(source_filename, destination_filename)

def read_graph_from_file(filename):
    graph = Graph()
    hostsports=[]
    with open(filename, 'r') as file:
        for line in file:
            if "%" in line:
                hostsports.append(line[1])
            else:
                start, end, weight, portS, portD = map(float, line.split())
                graph.add_edge(start, end, weight, portS, portD)
    print(hostsports)
    return (hostsports,graph)


if __name__ == "__main__":
    filename = "graf.txt"
    hostports, my_graph = read_graph_from_file(filename)
    my_graph.print_graph()
    my_graph.copy_and_save("template.json", "tosend.json")
    odp=input(("Czy chcesz dodac nowe polaczenie?"))
    while(odp=="t"):
        if(odp=="t"):
            start_vertex = int(input("Podaj pierwszy wierzchołek:"))
            end_vertex = int(input("Podaj ostatni wierzchołek:"))
            shortest_distance, shortest_path = my_graph.dijkstra(start_vertex, end_vertex)
            print(f"\nNajkrótsza ścieżka od wierzchołka {start_vertex} do {end_vertex}:")
            print(f"Długość ścieżki: {shortest_distance}")
            print(f"Ścieżka: {shortest_path}")
            my_graph.file_builder_switch_host_setup("tosend.json",shortest_path,hostports)
            my_graph.file_builder_switch_switch_setup("tosend.json", shortest_path, hostports)
            odp = input(("Czy chcesz dodac nowe polaczenie?"))





